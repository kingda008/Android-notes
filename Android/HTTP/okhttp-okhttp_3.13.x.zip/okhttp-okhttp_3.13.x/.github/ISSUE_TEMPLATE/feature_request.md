---
name: Feature request
about: Suggest an idea
title: ''
labels: enhancement
assignees: ''

---

Start by telling us what problem you’re trying to solve. Often a solution already exists!

Don’t send pull requests to implement new features without first getting our support. Sometimes we leave features out on purpose to keep the project small.
