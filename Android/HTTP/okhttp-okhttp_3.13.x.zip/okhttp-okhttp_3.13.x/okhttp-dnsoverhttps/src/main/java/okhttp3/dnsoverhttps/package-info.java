/** A DNS over HTTPS implementation for OkHttp. */
@okhttp3.internal.annotations.EverythingIsNonNull
package okhttp3.dnsoverhttps;
