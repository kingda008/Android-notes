/** Support for server-sent events. */
@okhttp3.internal.annotations.EverythingIsNonNull
package okhttp3.sse;
